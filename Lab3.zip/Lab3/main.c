/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.c
 * Author: Alvin
 *
 * Created on February 4, 2016, 9:37 AM
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>

/*
 * 
 */
void parsechar(char *arg[], char a[], int count);

int main(int argc, char* argv[]) {
    int ch, i = 0, j, flag = 0, count;
    pid_t pid;
    int status;
    char *a = malloc(100);
    while (1) {
        i = 0;
        count = 1;
        printf("Your Command >>: ");
        while ((ch = getchar()) != '\n') {
            if (ch == ' ') {
                a[i++] = '\0';
                count++;
            } else
                a[i++] = ch;
        }
        a[i] = '\n';

        if (a[i - 1] == '&') {
            flag = 1;
            printf("You have entered a '&' at the end, now the parent wont wait!\n");
        }

        char **arg = (char **) malloc(sizeof (char));
        parsechar(arg, a, count);

        if ((pid = fork()) == 0) {
            printf("Child (PID = %d) will now exec\n", getpid());
            execvp(arg[0], arg);
            exit(1);
        } else if (pid > 0) {
            if (flag != 1)
                wait(&status);
        }
        printf("Hello from parent with child %d\n", pid);


    }
    return (EXIT_SUCCESS);
}

void parsechar(char *arg[], char a[], int count) {
    int j, i = 0;
    arg[i++] = &a[0];
    if (count > 1) {
        for (j = 0; j < 100; j++) {
            if (a[j] == '\0')
                arg[i++] = &a[j + 1];
            else if(a[j]== '\n'){
                a[j] = '\0';
                break;
            }
        }
    }
    arg[i] = '\0';

    printf("You entered %d input\n", count);

    for (i = 0; i < count; i++)
        printf("arg[%d] = %s\n", i, arg[i]);

}


